import "../style/CouncilPtaMenber.css";
import React, { useState } from 'react';
import CouncilPopup1 from "./CouncilPopup1";


function CouncilPtaMenber() {
  const [isHouseHovered, setIsHouseHovered] = useState(false);
  const [isPerfectsHovered, setIsPerfectsHovered] = useState(false);
  const [isTeacherHovered, setIsTeacherHovered] = useState(false);
  const [isElectedHovered, setIsElectedHovered] = useState(false);

  const handleHouseMouseOver = () => {
    setIsHouseHovered(true);
  };

  const handleHouseMouseOut = () => {
    setIsHouseHovered(false);
  };

  const handlePerfectsMouseOver = () => {
    setIsPerfectsHovered(true);
  };

  const handlePerfectsMouseOut = () => {
    setIsPerfectsHovered(false);
  };

  const handleTeacherMouseOver = () => {
    setIsTeacherHovered(true);
  };

  const handleTeacherMouseOut = () => {
    setIsTeacherHovered(false);
  };

  const handleElectedMouseOver = () => {
    setIsElectedHovered(true);
  };

  const handleElectedMouseOut = () => {
    setIsElectedHovered(false);
  };

  function myFunctions() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
  }
  return (
    <>
    <div className='Council-pta-container'>
      <div className="council-image">
          <img src="../images/people_image.png" alt="people_image" className='council_image' width="1180px" height="520px"></img>
          <div className="council-image-text">
            Students Council & PTA Members
          </div>
      </div>        
    </div>
    <div className="student-council-text">
      <div className="StudentsCouncil">STUDENTS COUNCIL<br/></div>
        <div className="councilImage">

          <img src='../images/tudent-council1.png' alt='student-council' width="650" height="235"></img>
        </div>
        <div style={{textAlign: 'center'}}>
        <div className="councilText" style={{width: '1100px', height: 'auto', textAlign: 'justify', color: 'black', fontSize: '18px', fontFamily: 'Poppins', fontWeight: '500', lineHeight: '1.30', letterSpacing: '0.40px', wordWrap: 'break-word', margin: 'auto'}}>It is a students’ body established to put into practice the aims and objectives of the house system. The council is made up of a Head boy, a Head girl, school captains, school vice-captains as well as house prefects, monitors of the classes, and other representatives of the various activities and organizations. The meetings of the council are conducted on a parliamentary basis and the Council fulfills its purpose by assisting the principal and the teaching and non-teaching staff in carrying out the various affairs in the school. The council members help in maintaining the discipline of the school and take care of their student fellows in a compassionate manner.<br/>To felicitate the newly elected student council, the swearing-in ceremony was organized by Guru Harkrishan High School & Junior College of Commerce on 18th July 2022 in the school hall.The event began with a march past by the newly elected prefects along with the House Captains. All the teacher convenors pinned the badges and put sashes on the elected / selected students.The student council members contribute to the school discipline and students’ welfare. They help in organising the school activities.</div>
        </div>
    </div>
    <div className="popup-container">
      <div className="popup1">
        <div className={`house-system ${isHouseHovered ? 'hovered' : ''}`} onMouseOver={handleHouseMouseOver} onMouseOut={handleHouseMouseOut} onClick={myFunctions}>
        <div className="HouseSystem"  style={{ marginTop: isHouseHovered ? '10px' : '20px'}}>house  system 
        <div className="KnowMore" style={{color: '#CD5C5C', fontSize: 20, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 1.30, letterSpacing: 0.44, wordWrap: 'break-word' ,marginTop:10,marginLeft:325,textTransform:'none',marginTop: isHouseHovered ? '35px' : '55px'}}>Know more
        <img src="../images/Arrow 1.png" alt='arrow' style={{marginLeft:7}}/></div>
       </div>
       <span class="popuptext" id="myPopup"><h3 className="HouseSystemHeader">House  &nbsp; System</h3>
          <p>In order to inculcate a healthy spirit of competition and to get the best out of each individual student, our school students are divided into four houses to encourage them to participate in various activities and to get more and more scores for their respective houses. Even the teachers belong to the various houses and we have one teacher who heads the house and a team of teachers who belong to each house. Thus the house system induces a spirit of belongingness to the institution and the students work hard for the scores of their houses.</p></span>

        </div>
        <div className="perfects" onMouseOver={handlePerfectsMouseOver} onMouseOut={handlePerfectsMouseOut}>
          <div className="perfectSystem" style={{ marginTop: isPerfectsHovered  ? '10px' : '20px' }}>PREFECTS
          <div className="KnowMore" style={{color: '#CD5C5C', fontSize: 20, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 1.30, letterSpacing: 0.44, wordWrap: 'break-word',marginTop:49 ,marginLeft:325,textTransform:'none',marginTop: isPerfectsHovered ? '40px' : '55px'}}>Know more
        <img src="../images/Arrow 1.png" alt='arrow' style={{marginLeft:7}}/></div>
          </div>

        </div>
        
      </div>
      <div className="popup2">
        
        <div className="teacher-represent" onMouseOver={handleTeacherMouseOver} onMouseOut={handleTeacherMouseOut}>
        <div className="teacherSystem" style={{ marginTop: isTeacherHovered ? '-10px' : '0px' }}>Teacher Representative
        <div className="KnowMore" style={{color: '#FFDED6', fontSize: 20, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 1.30, letterSpacing: 0.44, wordWrap: 'break-word',marginTop:10 ,marginLeft:325,textTransform:'none',marginTop: isTeacherHovered ? '30px' : '45px'}}>Know more
        <img src="../images/Arrow 2.png" alt='arrow' style={{marginLeft:7}}/></div>
        </div>

        </div>
        <div className="elected-represent" onMouseOver={handleElectedMouseOver} onMouseOut={handleElectedMouseOut}>
          <div className="electedSystem" style={{ marginTop: isElectedHovered ? '-10px' : '0px' }}>P.T.A NEWLY ELECTED REPRESENTATIVE MEMBERS - 2023-2024
          <div className="KnowMore" style={{color: '#CD5C5C', fontSize: 20, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 1.30, letterSpacing: 0.44, wordWrap: 'break-word',marginTop:4 ,marginLeft:323,textTransform:'none',marginTop: isElectedHovered ? '0px' : '18px'}}>Know more
        <img src="../images/Arrow 1.png" alt='arrow' style={{marginLeft:7}}/></div>
          </div>

        </div>

      </div>
    </div>
    


  </>
  )
}

export default CouncilPtaMenber
